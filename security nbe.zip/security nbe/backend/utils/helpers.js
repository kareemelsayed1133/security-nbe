// Helper functions

// Example: Format date
exports.formatDate = (date) => {
    return new Date(date).toLocaleDateString();
};

// Example: Generate random ID
exports.generateRandomId = () => {
    return Math.random().toString(36).substr(2, 9);
};
