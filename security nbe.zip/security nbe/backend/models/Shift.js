const mongoose = require('mongoose');

const ShiftSchema = new mongoose.Schema({
    guard: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    branch: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Branch',
        required: true
    },
    startTime: {
        type: Date,
        required: true
    },
    endTime: {
        type: Date,
        required: true
    }
}, { timestamps: true });

module.exports = mongoose.model('Shift', ShiftSchema);
