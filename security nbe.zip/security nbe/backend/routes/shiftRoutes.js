const express = require('express');
const router = express.Router();
const shiftController = require('../controllers/shiftController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// @route   GET api/shifts
// @desc    Get all shifts
// @access  Private
router.get('/', auth, shiftController.getAllShifts);

// @route   GET api/shifts/:id
// @desc    Get shift by ID
// @access  Private
router.get('/:id', auth, shiftController.getShiftById);

// @route   POST api/shifts
// @desc    Create new shift
// @access  Private/Supervisor
router.post('/', auth, roleCheck(['Supervisor', 'Admin']), shiftController.createShift);

// @route   PUT api/shifts/:id
// @desc    Update shift
// @access  Private/Supervisor
router.put('/:id', auth, roleCheck(['Supervisor', 'Admin']), shiftController.updateShift);

// @route   DELETE api/shifts/:id
// @desc    Delete shift
// @access  Private/Supervisor
router.delete('/:id', auth, roleCheck(['Supervisor', 'Admin']), shiftController.deleteShift);

module.exports = router;
