const express = require('express');
const router = express.Router();
const assetController = require('../controllers/assetController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// @route   GET api/assets
// @desc    Get all assets
// @access  Private
router.get('/', auth, assetController.getAllAssets);

// @route   GET api/assets/:id
// @desc    Get asset by ID
// @access  Private
router.get('/:id', auth, assetController.getAssetById);

// @route   POST api/assets
// @desc    Create new asset
// @access  Private/Supervisor
router.post('/', auth, roleCheck(['Supervisor', 'Admin']), assetController.createAsset);

// @route   PUT api/assets/:id
// @desc    Update asset
// @access  Private/Supervisor
router.put('/:id', auth, roleCheck(['Supervisor', 'Admin']), assetController.updateAsset);

// @route   DELETE api/assets/:id
// @desc    Delete asset
// @access  Private/Supervisor
router.delete('/:id', auth, roleCheck(['Supervisor', 'Admin']), assetController.deleteAsset);

module.exports = router;
