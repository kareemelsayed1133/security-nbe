const express = require('express');
const router = express.Router();
const incidentController = require('../controllers/incidentController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// @route   GET api/incidents
// @desc    Get all incidents
// @access  Private
router.get('/', auth, incidentController.getAllIncidents);

// @route   GET api/incidents/:id
// @desc    Get incident by ID
// @access  Private
router.get('/:id', auth, incidentController.getIncidentById);

// @route   POST api/incidents
// @desc    Create new incident
// @access  Private/Supervisor
router.post('/', auth, roleCheck(['Supervisor', 'Admin']), incidentController.createIncident);

// @route   PUT api/incidents/:id
// @desc    Update incident
// @access  Private/Supervisor
router.put('/:id', auth, roleCheck(['Supervisor', 'Admin']), incidentController.updateIncident);

// @route   DELETE api/incidents/:id
// @desc    Delete incident
// @access  Private/Supervisor
router.delete('/:id', auth, roleCheck(['Supervisor', 'Admin']), incidentController.deleteIncident);

module.exports = router;
