const express = require('express');
const router = express.Router();
const messageController = require('../controllers/messageController');
const auth = require('../middleware/auth');

// @route   GET api/messages
// @desc    Get all messages for a user
// @access  Private
router.get('/', auth, messageController.getUserMessages);

// @route   POST api/messages
// @desc    Send a message
// @access  Private
router.post('/', auth, messageController.sendMessage);

// @route   DELETE api/messages/:id
// @desc    Delete message
// @access  Private
router.delete('/:id', auth, messageController.deleteMessage);

module.exports = router;
