const express = require('express');
const router = express.Router();
const deviceController = require('../controllers/deviceController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// @route   GET api/devices
// @desc    Get all devices
// @access  Private
router.get('/', auth, deviceController.getAllDevices);

// @route   GET api/devices/:id
// @desc    Get device by ID
// @access  Private
router.get('/:id', auth, deviceController.getDeviceById);

// @route   POST api/devices
// @desc    Create new device
// @access  Private/Supervisor
router.post('/', auth, roleCheck(['Supervisor', 'Admin']), deviceController.createDevice);

// @route   PUT api/devices/:id
// @desc    Update device
// @access  Private/Supervisor
router.put('/:id', auth, roleCheck(['Supervisor', 'Admin']), deviceController.updateDevice);

// @route   DELETE api/devices/:id
// @desc    Delete device
// @access  Private/Supervisor
router.delete('/:id', auth, roleCheck(['Supervisor', 'Admin']), deviceController.deleteDevice);

module.exports = router;
