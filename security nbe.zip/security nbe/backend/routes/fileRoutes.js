const express = require('express');
const router = express.Router();
const fileUpload = require('../middleware/fileUpload');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// @route   POST api/files/upload
// @desc    Upload a file
// @access  Private
router.post('/upload', auth, roleCheck(['Supervisor', 'Admin']), fileUpload.single('file'), (req, res) => {
    try {
        res.json({ filePath: req.file.path });
    } catch (err) {
        res.status(500).send('Server error');
    }
});

module.exports = router;
