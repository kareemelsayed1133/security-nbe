const express = require('express');
const router = express.Router();
const branchController = require('../controllers/branchController');
const auth = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

// @route   GET api/branches
// @desc    Get all branches
// @access  Private
router.get('/', auth, branchController.getAllBranches);

// @route   GET api/branches/:id
// @desc    Get branch by ID
// @access  Private
router.get('/:id', auth, branchController.getBranchById);

// @route   POST api/branches
// @desc    Create new branch
// @access  Private/Admin
router.post('/', auth, roleCheck(['Admin']), branchController.createBranch);

// @route   PUT api/branches/:id
// @desc    Update branch
// @access  Private/Admin
router.put('/:id', auth, roleCheck(['Admin']), branchController.updateBranch);

// @route   DELETE api/branches/:id
// @desc    Delete branch
// @access  Private/Admin
router.delete('/:id', auth, roleCheck(['Admin']), branchController.deleteBranch);

module.exports = router;
