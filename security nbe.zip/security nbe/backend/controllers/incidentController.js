const Incident = require('../models/Incident');

// Get all incidents
exports.getAllIncidents = async (req, res) => {
    try {
        const incidents = await Incident.find().populate('branch reportedBy');
        res.json(incidents);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Get incident by ID
exports.getIncidentById = async (req, res) => {
    try {
        const incident = await Incident.findById(req.params.id).populate('branch reportedBy');
        if (!incident) {
            return res.status(404).json({ msg: 'Incident not found' });
        }
        res.json(incident);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Create new incident
exports.createIncident = async (req, res) => {
    const { title, description, branch, reportedBy } = req.body;
    try {
        const newIncident = new Incident({ title, description, branch, reportedBy });
        const incident = await newIncident.save();
        res.json(incident);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Update incident
exports.updateIncident = async (req, res) => {
    const { title, description, branch } = req.body;
    try {
        let incident = await Incident.findById(req.params.id);
        if (!incident) {
            return res.status(404).json({ msg: 'Incident not found' });
        }
        incident.title = title || incident.title;
        incident.description = description || incident.description;
        incident.branch = branch || incident.branch;
        await incident.save();
        res.json(incident);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Delete incident
exports.deleteIncident = async (req, res) => {
    try {
        await Incident.findByIdAndRemove(req.params.id);
        res.json({ msg: 'Incident removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
