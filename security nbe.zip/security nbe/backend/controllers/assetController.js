const Asset = require('../models/Asset');

// Get all assets
exports.getAllAssets = async (req, res) => {
    try {
        const assets = await Asset.find().populate('branch');
        res.json(assets);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Get asset by ID
exports.getAssetById = async (req, res) => {
    try {
        const asset = await Asset.findById(req.params.id).populate('branch');
        if (!asset) {
            return res.status(404).json({ msg: 'Asset not found' });
        }
        res.json(asset);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Create new asset
exports.createAsset = async (req, res) => {
    const { name, type, value, branch } = req.body;
    try {
        const newAsset = new Asset({ name, type, value, branch });
        const asset = await newAsset.save();
        res.json(asset);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Update asset
exports.updateAsset = async (req, res) => {
    const { name, type, value, branch } = req.body;
    try {
        let asset = await Asset.findById(req.params.id);
        if (!asset) {
            return res.status(404).json({ msg: 'Asset not found' });
        }
        asset.name = name || asset.name;
        asset.type = type || asset.type;
        asset.value = value || asset.value;
        asset.branch = branch || asset.branch;
        await asset.save();
        res.json(asset);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Delete asset
exports.deleteAsset = async (req, res) => {
    try {
        await Asset.findByIdAndRemove(req.params.id);
        res.json({ msg: 'Asset removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
