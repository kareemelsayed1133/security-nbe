const Message = require('../models/Message');

// Get all messages for a user
exports.getUserMessages = async (req, res) => {
    try {
        const messages = await Message.find({ $or: [{ sender: req.user.id }, { receiver: req.user.id }] });
        res.json(messages);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Send a message
exports.sendMessage = async (req, res) => {
    const { receiver, content } = req.body;
    try {
        const newMessage = new Message({ sender: req.user.id, receiver, content });
        const message = await newMessage.save();
        res.json(message);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Delete a message
exports.deleteMessage = async (req, res) => {
    try {
        await Message.findByIdAndRemove(req.params.id);
        res.json({ msg: 'Message removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
