const Shift = require('../models/Shift');

// Get all shifts
exports.getAllShifts = async (req, res) => {
    try {
        const shifts = await Shift.find().populate('guard branch');
        res.json(shifts);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Get shift by ID
exports.getShiftById = async (req, res) => {
    try {
        const shift = await Shift.findById(req.params.id).populate('guard branch');
        if (!shift) {
            return res.status(404).json({ msg: 'Shift not found' });
        }
        res.json(shift);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Create new shift
exports.createShift = async (req, res) => {
    const { guard, branch, startTime, endTime } = req.body;
    try {
        const newShift = new Shift({ guard, branch, startTime, endTime });
        const shift = await newShift.save();
        res.json(shift);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Update shift
exports.updateShift = async (req, res) => {
    const { guard, branch, startTime, endTime } = req.body;
    try {
        let shift = await Shift.findById(req.params.id);
        if (!shift) {
            return res.status(404).json({ msg: 'Shift not found' });
        }
        shift.guard = guard || shift.guard;
        shift.branch = branch || shift.branch;
        shift.startTime = startTime || shift.startTime;
        shift.endTime = endTime || shift.endTime;
        await shift.save();
        res.json(shift);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Delete shift
exports.deleteShift = async (req, res) => {
    try {
        await Shift.findByIdAndRemove(req.params.id);
        res.json({ msg: 'Shift removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
