const SecurityDevice = require('../models/SecurityDevice');

// Get all devices
exports.getAllDevices = async (req, res) => {
    try {
        const devices = await SecurityDevice.find().populate('branch');
        res.json(devices);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Get device by ID
exports.getDeviceById = async (req, res) => {
    try {
        const device = await SecurityDevice.findById(req.params.id).populate('branch');
        if (!device) {
            return res.status(404).json({ msg: 'Device not found' });
        }
        res.json(device);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Create new device
exports.createDevice = async (req, res) => {
    const { name, type, status, branch } = req.body;
    try {
        const newDevice = new SecurityDevice({ name, type, status, branch });
        const device = await newDevice.save();
        res.json(device);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Update device
exports.updateDevice = async (req, res) => {
    const { name, type, status, branch } = req.body;
    try {
        let device = await SecurityDevice.findById(req.params.id);
        if (!device) {
            return res.status(404).json({ msg: 'Device not found' });
        }
        device.name = name || device.name;
        device.type = type || device.type;
        device.status = status || device.status;
        device.branch = branch || device.branch;
        await device.save();
        res.json(device);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Delete device
exports.deleteDevice = async (req, res) => {
    try {
        await SecurityDevice.findByIdAndRemove(req.params.id);
        res.json({ msg: 'Device removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
