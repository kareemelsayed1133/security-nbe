const Branch = require('../models/Branch');

// Get all branches
exports.getAllBranches = async (req, res) => {
    try {
        const branches = await Branch.find().populate('manager');
        res.json(branches);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Get branch by ID
exports.getBranchById = async (req, res) => {
    try {
        const branch = await Branch.findById(req.params.id).populate('manager');
        if (!branch) {
            return res.status(404).json({ msg: 'Branch not found' });
        }
        res.json(branch);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Create new branch
exports.createBranch = async (req, res) => {
    const { name, location, manager } = req.body;
    try {
        const newBranch = new Branch({ name, location, manager });
        const branch = await newBranch.save();
        res.json(branch);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Update branch
exports.updateBranch = async (req, res) => {
    const { name, location, manager } = req.body;
    try {
        let branch = await Branch.findById(req.params.id);
        if (!branch) {
            return res.status(404).json({ msg: 'Branch not found' });
        }
        branch.name = name || branch.name;
        branch.location = location || branch.location;
        branch.manager = manager || branch.manager;
        await branch.save();
        res.json(branch);
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};

// Delete branch
exports.deleteBranch = async (req, res) => {
    try {
        await Branch.findByIdAndRemove(req.params.id);
        res.json({ msg: 'Branch removed' });
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server error');
    }
};
