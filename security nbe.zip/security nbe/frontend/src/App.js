import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import AuthProvider from './context/AuthContext';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Switch>
          <Route path="/" exact>
            <h1>Welcome to Security NBE</h1>
          </Route>
          {/* Add more routes here */}
        </Switch>
      </Router>
    </AuthProvider>
  );
}

export default App;
