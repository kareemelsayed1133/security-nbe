import React from 'react';
import Header from './Header';
import Sidebar from './Sidebar';

function Layout({ children }) {
  return (
    <div className="layout">
      <Header />
      <Sidebar />
      <main className="content">
        {children}
      </main>
    </div>
  );
}

export default Layout;
