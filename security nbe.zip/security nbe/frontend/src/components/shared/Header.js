import React from 'react';

function Header() {
  return (
    <header className="header">
      <h1>Security NBE</h1>
      {/* Add header components here */}
    </header>
  );
}

export default Header;
