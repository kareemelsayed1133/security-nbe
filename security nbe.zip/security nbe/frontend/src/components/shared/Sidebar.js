import React from 'react';

function Sidebar() {
  return (
    <aside className="sidebar">
      <nav>
        <ul>
          <li>Dashboard</li>
          <li>Management</li>
          {/* Add more navigation items here */}
        </ul>
      </nav>
    </aside>
  );
}

export default Sidebar;
