import React from 'react';

function Login() {
  return (
    <div className="login-page">
      <h1>Login</h1>
      {/* Add login form here */}
    </div>
  );
}

export default Login;
