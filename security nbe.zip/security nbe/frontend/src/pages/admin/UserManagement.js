import React from 'react';

function UserManagement() {
  return (
    <div className="user-management">
      <h1>User Management</h1>
      {/* Add user management components here */}
    </div>
  );
}

export default UserManagement;
