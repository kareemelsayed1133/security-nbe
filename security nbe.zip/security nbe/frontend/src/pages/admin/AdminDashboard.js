import React from 'react';

function AdminDashboard() {
  return (
    <div className="admin-dashboard">
      <h1>Admin Dashboard</h1>
      {/* Add admin dashboard components here */}
    </div>
  );
}

export default AdminDashboard;
