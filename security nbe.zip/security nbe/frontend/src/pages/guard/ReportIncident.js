import React from 'react';

function ReportIncident() {
  return (
    <div className="report-incident">
      <h1>Report Incident</h1>
      {/* Add report incident components here */}
    </div>
  );
}

export default ReportIncident;
