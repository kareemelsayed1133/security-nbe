import React from 'react';

function MyShifts() {
  return (
    <div className="my-shifts">
      <h1>My Shifts</h1>
      {/* Add my shifts components here */}
    </div>
  );
}

export default MyShifts;
