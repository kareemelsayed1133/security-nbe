import React from 'react';

function GuardDashboard() {
  return (
    <div className="guard-dashboard">
      <h1>Guard Dashboard</h1>
      {/* Add guard dashboard components here */}
    </div>
  );
}

export default GuardDashboard;
