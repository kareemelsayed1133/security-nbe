export const APP_NAME = 'Security NBE';
export const API_ENDPOINTS = {
  LOGIN: '/auth/login',
  REGISTER: '/auth/register',
  // Add more endpoints as needed
};
